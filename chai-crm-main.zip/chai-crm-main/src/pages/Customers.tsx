import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Search, 
  Plus, 
  Filter,
  MoreHorizontal,
  Mail,
  Phone,
  Calendar,
  Gift
} from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

const customers = [
  {
    id: "CUS-001",
    name: "Priya Sharma",
    email: "priya.sharma@email.com",
    phone: "+91 98765 43210",
    type: "Regular",
    totalOrders: 45,
    totalSpent: "₹12,450",
    birthday: "15 Mar",
    lastVisit: "2 days ago",
  },
  {
    id: "CUS-002",
    name: "Rahul Verma",
    email: "rahul.v@email.com",
    phone: "+91 87654 32109",
    type: "Enterprise",
    totalOrders: 128,
    totalSpent: "₹85,200",
    birthday: "22 Jul",
    lastVisit: "Today",
  },
  {
    id: "CUS-003",
    name: "Anita Patel",
    email: "anita.patel@email.com",
    phone: "+91 76543 21098",
    type: "New",
    totalOrders: 3,
    totalSpent: "₹890",
    birthday: "08 Dec",
    lastVisit: "1 week ago",
  },
  {
    id: "CUS-004",
    name: "Vikram Singh",
    email: "vikram.s@email.com",
    phone: "+91 65432 10987",
    type: "Regular",
    totalOrders: 67,
    totalSpent: "₹18,750",
    birthday: "30 Jan",
    lastVisit: "3 days ago",
  },
  {
    id: "CUS-005",
    name: "Meera Gupta",
    email: "meera.g@email.com",
    phone: "+91 54321 09876",
    type: "Enterprise",
    totalOrders: 89,
    totalSpent: "₹62,300",
    birthday: "11 Sep",
    lastVisit: "Yesterday",
  },
  {
    id: "CUS-006",
    name: "Arjun Reddy",
    email: "arjun.r@email.com",
    phone: "+91 43210 98765",
    type: "Regular",
    totalOrders: 23,
    totalSpent: "₹5,670",
    birthday: "05 May",
    lastVisit: "5 days ago",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function Customers() {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      customer.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AppLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-8"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-semibold text-foreground">
              Customers
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your customer database and track their activity.
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Customer
          </Button>
        </motion.div>

        {/* Stats */}
        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-4">
          <Card className="stat-card">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-semibold font-display">892</p>
                <p className="text-sm text-muted-foreground">Total Customers</p>
              </div>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-emerald-100 flex items-center justify-center">
                <Gift className="h-6 w-6 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold font-display">12</p>
                <p className="text-sm text-muted-foreground">Birthdays This Month</p>
              </div>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-amber-100 flex items-center justify-center">
                <Mail className="h-6 w-6 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold font-display">156</p>
                <p className="text-sm text-muted-foreground">Enterprise Accounts</p>
              </div>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-blue-100 flex items-center justify-center">
                <Phone className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-semibold font-display">47</p>
                <p className="text-sm text-muted-foreground">New This Month</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Search & Filter */}
        <motion.div variants={itemVariants} className="flex items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search customers..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filter
          </Button>
        </motion.div>

        {/* Table */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-center">Orders</TableHead>
                    <TableHead>Total Spent</TableHead>
                    <TableHead>Birthday</TableHead>
                    <TableHead>Last Visit</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.map((customer) => (
                    <TableRow key={customer.id} className="table-row-hover">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                            <span className="text-sm font-medium text-primary">
                              {customer.name.split(" ").map((n) => n[0]).join("")}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-xs text-muted-foreground">{customer.id}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <p className="text-sm">{customer.email}</p>
                        <p className="text-xs text-muted-foreground">{customer.phone}</p>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            customer.type === "Enterprise"
                              ? "default"
                              : customer.type === "Regular"
                              ? "secondary"
                              : "outline"
                          }
                        >
                          {customer.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">{customer.totalOrders}</TableCell>
                      <TableCell className="font-medium">{customer.totalSpent}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Gift className="h-3.5 w-3.5 text-muted-foreground" />
                          {customer.birthday}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{customer.lastVisit}</TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>View Profile</DropdownMenuItem>
                            <DropdownMenuItem>Edit Details</DropdownMenuItem>
                            <DropdownMenuItem>Send Email</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
