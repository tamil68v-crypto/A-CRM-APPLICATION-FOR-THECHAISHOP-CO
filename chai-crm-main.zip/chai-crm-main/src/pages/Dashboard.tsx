import { motion } from "framer-motion";
import { 
  TrendingUp, 
  Users, 
  ShoppingCart, 
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Coffee,
  Cake
} from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const stats = [
  {
    title: "Total Revenue",
    value: "₹2,45,890",
    change: "+12.5%",
    trend: "up",
    icon: DollarSign,
    description: "vs last month",
  },
  {
    title: "Total Orders",
    value: "1,284",
    change: "+8.2%",
    trend: "up",
    icon: ShoppingCart,
    description: "vs last month",
  },
  {
    title: "Active Customers",
    value: "892",
    change: "+15.3%",
    trend: "up",
    icon: Users,
    description: "vs last month",
  },
  {
    title: "Avg Order Value",
    value: "₹191",
    change: "-2.4%",
    trend: "down",
    icon: TrendingUp,
    description: "vs last month",
  },
];

const salesData = [
  { name: "Mon", tea: 4200, bakery: 2400 },
  { name: "Tue", tea: 3800, bakery: 2800 },
  { name: "Wed", tea: 5100, bakery: 3200 },
  { name: "Thu", tea: 4600, bakery: 2900 },
  { name: "Fri", tea: 6200, bakery: 4100 },
  { name: "Sat", tea: 7800, bakery: 5200 },
  { name: "Sun", tea: 6500, bakery: 4800 },
];

const topProducts = [
  { name: "Masala Chai", sales: 245, category: "tea" },
  { name: "Green Tea", sales: 198, category: "tea" },
  { name: "Butter Croissant", sales: 156, category: "bakery" },
  { name: "Darjeeling Special", sales: 142, category: "tea" },
  { name: "Chocolate Muffin", sales: 128, category: "bakery" },
];

const orderTypeData = [
  { name: "Walk-in", value: 58, color: "hsl(32, 80%, 45%)" },
  { name: "Online", value: 42, color: "hsl(25, 45%, 25%)" },
];

const recentOrders = [
  { id: "ORD-001", customer: "Priya Sharma", total: "₹450", status: "completed", type: "walk-in" },
  { id: "ORD-002", customer: "Rahul Verma", total: "₹280", status: "pending", type: "online" },
  { id: "ORD-003", customer: "Anita Patel", total: "₹620", status: "completed", type: "online" },
  { id: "ORD-004", customer: "Vikram Singh", total: "₹175", status: "completed", type: "walk-in" },
  { id: "ORD-005", customer: "Meera Gupta", total: "₹340", status: "pending", type: "online" },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function Dashboard() {
  return (
    <AppLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-8"
      >
        {/* Header */}
        <motion.div variants={itemVariants}>
          <h1 className="font-display text-3xl font-semibold text-foreground">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Welcome back! Here's what's happening at TheChaiShop&Co today.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              variants={itemVariants}
              className="stat-card"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </p>
                  <p className="text-2xl font-semibold mt-2 font-display">
                    {stat.value}
                  </p>
                </div>
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <stat.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
              <div className="flex items-center gap-1 mt-4">
                {stat.trend === "up" ? (
                  <ArrowUpRight className="h-4 w-4 text-emerald-600" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 text-red-500" />
                )}
                <span className={stat.trend === "up" ? "text-emerald-600" : "text-red-500"}>
                  {stat.change}
                </span>
                <span className="text-sm text-muted-foreground">
                  {stat.description}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Charts Row */}
        <motion.div variants={itemVariants} className="grid gap-6 lg:grid-cols-3">
          {/* Sales Chart */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="font-display">Weekly Sales</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={salesData}>
                    <defs>
                      <linearGradient id="teaGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(32, 80%, 45%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(32, 80%, 45%)" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="bakeryGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(25, 45%, 25%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(25, 45%, 25%)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(35, 25%, 85%)" />
                    <XAxis dataKey="name" stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <YAxis stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(40, 30%, 97%)", 
                        border: "1px solid hsl(35, 25%, 85%)",
                        borderRadius: "8px"
                      }} 
                    />
                    <Area
                      type="monotone"
                      dataKey="tea"
                      stroke="hsl(32, 80%, 45%)"
                      strokeWidth={2}
                      fill="url(#teaGradient)"
                      name="Tea Products"
                    />
                    <Area
                      type="monotone"
                      dataKey="bakery"
                      stroke="hsl(25, 45%, 25%)"
                      strokeWidth={2}
                      fill="url(#bakeryGradient)"
                      name="Bakery Items"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Order Type Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Order Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[220px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={orderTypeData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {orderTypeData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-6 mt-4">
                {orderTypeData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div 
                      className="h-3 w-3 rounded-full" 
                      style={{ backgroundColor: entry.color }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {entry.name} ({entry.value}%)
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Bottom Row */}
        <motion.div variants={itemVariants} className="grid gap-6 lg:grid-cols-2">
          {/* Top Products */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Top Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topProducts.map((product, index) => (
                  <div key={product.name} className="flex items-center gap-4">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                      {product.category === "tea" ? (
                        <Coffee className="h-4 w-4 text-primary" />
                      ) : (
                        <Cake className="h-4 w-4 text-primary" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{product.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {product.category}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-sm">{product.sales}</p>
                      <p className="text-xs text-muted-foreground">sales</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders.map((order) => (
                  <div key={order.id} className="flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-sm">{order.id}</p>
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
                          order.type === "online" ? "badge-online" : "badge-walkin"
                        }`}>
                          {order.type}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {order.customer}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-sm">{order.total}</p>
                      <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
                        order.status === "completed" ? "badge-completed" : "badge-pending"
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
