import { motion } from "framer-motion";
import { Download, Calendar } from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const monthlySalesData = [
  { month: "Jan", revenue: 185000, orders: 890 },
  { month: "Feb", revenue: 195000, orders: 920 },
  { month: "Mar", revenue: 220000, orders: 1050 },
  { month: "Apr", revenue: 198000, orders: 940 },
  { month: "May", revenue: 235000, orders: 1120 },
  { month: "Jun", revenue: 245890, orders: 1284 },
];

const productCategoryData = [
  { name: "Masala Chai", value: 28 },
  { name: "Green Tea", value: 22 },
  { name: "Darjeeling", value: 18 },
  { name: "Bakery Items", value: 20 },
  { name: "Other Teas", value: 12 },
];

const categoryColors = [
  "hsl(32, 80%, 45%)",
  "hsl(142, 50%, 45%)",
  "hsl(25, 45%, 25%)",
  "hsl(40, 70%, 55%)",
  "hsl(200, 50%, 50%)",
];

const customerGrowthData = [
  { month: "Jan", new: 45, returning: 320 },
  { month: "Feb", new: 52, returning: 345 },
  { month: "Mar", new: 68, returning: 380 },
  { month: "Apr", new: 55, returning: 365 },
  { month: "May", new: 72, returning: 410 },
  { month: "Jun", new: 89, returning: 445 },
];

const hourlyTrafficData = [
  { hour: "8AM", orders: 12 },
  { hour: "9AM", orders: 28 },
  { hour: "10AM", orders: 45 },
  { hour: "11AM", orders: 52 },
  { hour: "12PM", orders: 38 },
  { hour: "1PM", orders: 32 },
  { hour: "2PM", orders: 28 },
  { hour: "3PM", orders: 35 },
  { hour: "4PM", orders: 48 },
  { hour: "5PM", orders: 62 },
  { hour: "6PM", orders: 58 },
  { hour: "7PM", orders: 42 },
  { hour: "8PM", orders: 25 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function Reports() {
  return (
    <AppLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-8"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-semibold text-foreground">
              Reports & Analytics
            </h1>
            <p className="text-muted-foreground mt-1">
              Analyze sales performance and customer activity.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              Last 6 Months
            </Button>
            <Button className="gap-2">
              <Download className="h-4 w-4" />
              Export Report
            </Button>
          </div>
        </motion.div>

        {/* Revenue Chart */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Revenue & Orders Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={monthlySalesData}>
                    <defs>
                      <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(32, 80%, 45%)" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(32, 80%, 45%)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(35, 25%, 85%)" />
                    <XAxis dataKey="month" stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <YAxis 
                      yAxisId="revenue"
                      stroke="hsl(25, 15%, 45%)" 
                      fontSize={12}
                      tickFormatter={(value) => `₹${(value / 1000)}k`}
                    />
                    <YAxis 
                      yAxisId="orders"
                      orientation="right"
                      stroke="hsl(25, 15%, 45%)" 
                      fontSize={12}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(40, 30%, 97%)", 
                        border: "1px solid hsl(35, 25%, 85%)",
                        borderRadius: "8px"
                      }}
                      formatter={(value: number, name: string) => [
                        name === "revenue" ? `₹${value.toLocaleString()}` : value,
                        name === "revenue" ? "Revenue" : "Orders"
                      ]}
                    />
                    <Legend />
                    <Area
                      yAxisId="revenue"
                      type="monotone"
                      dataKey="revenue"
                      stroke="hsl(32, 80%, 45%)"
                      strokeWidth={2}
                      fill="url(#revenueGradient)"
                      name="Revenue"
                    />
                    <Line
                      yAxisId="orders"
                      type="monotone"
                      dataKey="orders"
                      stroke="hsl(25, 45%, 25%)"
                      strokeWidth={2}
                      dot={{ fill: "hsl(25, 45%, 25%)", strokeWidth: 0 }}
                      name="Orders"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Second Row */}
        <motion.div variants={itemVariants} className="grid gap-6 lg:grid-cols-2">
          {/* Product Categories */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Sales by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={productCategoryData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                      labelLine={false}
                    >
                      {productCategoryData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={categoryColors[index]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Customer Growth */}
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Customer Growth</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={customerGrowthData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(35, 25%, 85%)" />
                    <XAxis dataKey="month" stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <YAxis stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(40, 30%, 97%)", 
                        border: "1px solid hsl(35, 25%, 85%)",
                        borderRadius: "8px"
                      }}
                    />
                    <Legend />
                    <Bar dataKey="new" name="New Customers" fill="hsl(32, 80%, 45%)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="returning" name="Returning" fill="hsl(25, 45%, 25%)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Hourly Traffic */}
        <motion.div variants={itemVariants}>
          <Card>
            <CardHeader>
              <CardTitle className="font-display">Peak Hours Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={hourlyTrafficData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(35, 25%, 85%)" />
                    <XAxis dataKey="hour" stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <YAxis stroke="hsl(25, 15%, 45%)" fontSize={12} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(40, 30%, 97%)", 
                        border: "1px solid hsl(35, 25%, 85%)",
                        borderRadius: "8px"
                      }}
                    />
                    <Bar 
                      dataKey="orders" 
                      name="Orders" 
                      fill="hsl(32, 80%, 45%)" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}
