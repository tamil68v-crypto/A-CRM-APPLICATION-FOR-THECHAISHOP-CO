import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Search, 
  Plus, 
  Filter,
  MoreHorizontal,
  Eye,
  Printer,
  Coffee,
  Cake
} from "lucide-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const orders = [
  {
    id: "ORD-001",
    customer: "Priya Sharma",
    email: "priya.sharma@email.com",
    type: "walk-in",
    items: [
      { name: "Masala Chai", qty: 2, price: 80 },
      { name: "Butter Croissant", qty: 1, price: 120 },
    ],
    total: "₹280",
    status: "completed",
    date: "Today, 10:45 AM",
    paymentMethod: "Cash",
  },
  {
    id: "ORD-002",
    customer: "Rahul Verma",
    email: "rahul.v@email.com",
    type: "online",
    items: [
      { name: "Green Tea (250g)", qty: 2, price: 450 },
      { name: "Darjeeling Special (100g)", qty: 1, price: 380 },
    ],
    total: "₹1,280",
    status: "pending",
    date: "Today, 9:30 AM",
    paymentMethod: "UPI",
  },
  {
    id: "ORD-003",
    customer: "Anita Patel",
    email: "anita.patel@email.com",
    type: "online",
    items: [
      { name: "Assam Tea (500g)", qty: 1, price: 650 },
      { name: "Chocolate Muffin (6pc)", qty: 2, price: 240 },
    ],
    total: "₹1,130",
    status: "completed",
    date: "Yesterday, 4:15 PM",
    paymentMethod: "Card",
  },
  {
    id: "ORD-004",
    customer: "Vikram Singh",
    email: "vikram.s@email.com",
    type: "walk-in",
    items: [
      { name: "Ginger Tea", qty: 3, price: 90 },
      { name: "Veg Puff", qty: 2, price: 60 },
    ],
    total: "₹390",
    status: "completed",
    date: "Yesterday, 2:00 PM",
    paymentMethod: "Cash",
  },
  {
    id: "ORD-005",
    customer: "Meera Gupta",
    email: "meera.g@email.com",
    type: "online",
    items: [
      { name: "Earl Grey (200g)", qty: 3, price: 520 },
    ],
    total: "₹1,560",
    status: "pending",
    date: "Yesterday, 11:30 AM",
    paymentMethod: "UPI",
  },
  {
    id: "ORD-006",
    customer: "Arjun Reddy",
    email: "arjun.r@email.com",
    type: "walk-in",
    items: [
      { name: "Lemon Tea", qty: 1, price: 70 },
      { name: "Samosa", qty: 2, price: 40 },
    ],
    total: "₹150",
    status: "cancelled",
    date: "2 days ago",
    paymentMethod: "Cash",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

export default function Orders() {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.customer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.id.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === "all") return matchesSearch;
    if (activeTab === "online") return matchesSearch && order.type === "online";
    if (activeTab === "walk-in") return matchesSearch && order.type === "walk-in";
    if (activeTab === "pending") return matchesSearch && order.status === "pending";
    return matchesSearch;
  });

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "completed":
        return "badge-completed";
      case "pending":
        return "badge-pending";
      case "cancelled":
        return "badge-cancelled";
      default:
        return "";
    }
  };

  return (
    <AppLayout>
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="space-y-8"
      >
        {/* Header */}
        <motion.div variants={itemVariants} className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-semibold text-foreground">
              Orders
            </h1>
            <p className="text-muted-foreground mt-1">
              Track and manage all customer orders.
            </p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            New Order
          </Button>
        </motion.div>

        {/* Stats Cards */}
        <motion.div variants={itemVariants} className="grid gap-6 md:grid-cols-4">
          <Card className="stat-card">
            <div className="text-center">
              <p className="text-3xl font-semibold font-display text-foreground">1,284</p>
              <p className="text-sm text-muted-foreground mt-1">Total Orders</p>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="text-center">
              <p className="text-3xl font-semibold font-display text-emerald-600">₹2,45,890</p>
              <p className="text-sm text-muted-foreground mt-1">Total Revenue</p>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="text-center">
              <p className="text-3xl font-semibold font-display text-amber-600">23</p>
              <p className="text-sm text-muted-foreground mt-1">Pending Orders</p>
            </div>
          </Card>
          <Card className="stat-card">
            <div className="text-center">
              <p className="text-3xl font-semibold font-display text-foreground">₹191</p>
              <p className="text-sm text-muted-foreground mt-1">Avg Order Value</p>
            </div>
          </Card>
        </motion.div>

        {/* Tabs & Search */}
        <motion.div variants={itemVariants}>
          <Tabs defaultValue="all" onValueChange={setActiveTab}>
            <div className="flex items-center justify-between mb-4">
              <TabsList>
                <TabsTrigger value="all">All Orders</TabsTrigger>
                <TabsTrigger value="online">Online</TabsTrigger>
                <TabsTrigger value="walk-in">Walk-in</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
              </TabsList>
              <div className="flex items-center gap-4">
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search orders..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button variant="outline" className="gap-2">
                  <Filter className="h-4 w-4" />
                  Filter
                </Button>
              </div>
            </div>

            <TabsContent value="all" className="mt-0">
              <OrdersTable orders={filteredOrders} getStatusBadgeClass={getStatusBadgeClass} />
            </TabsContent>
            <TabsContent value="online" className="mt-0">
              <OrdersTable orders={filteredOrders} getStatusBadgeClass={getStatusBadgeClass} />
            </TabsContent>
            <TabsContent value="walk-in" className="mt-0">
              <OrdersTable orders={filteredOrders} getStatusBadgeClass={getStatusBadgeClass} />
            </TabsContent>
            <TabsContent value="pending" className="mt-0">
              <OrdersTable orders={filteredOrders} getStatusBadgeClass={getStatusBadgeClass} />
            </TabsContent>
          </Tabs>
        </motion.div>
      </motion.div>
    </AppLayout>
  );
}

interface OrdersTableProps {
  orders: typeof orders;
  getStatusBadgeClass: (status: string) => string;
}

function OrdersTable({ orders, getStatusBadgeClass }: OrdersTableProps) {
  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Items</TableHead>
              <TableHead>Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead className="w-10"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id} className="table-row-hover">
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{order.customer}</p>
                    <p className="text-xs text-muted-foreground">{order.email}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border ${
                    order.type === "online" ? "badge-online" : "badge-walkin"
                  }`}>
                    {order.type}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    {order.items.some(item => 
                      item.name.toLowerCase().includes("tea") || 
                      item.name.toLowerCase().includes("chai")
                    ) && (
                      <Coffee className="h-4 w-4 text-primary" />
                    )}
                    {order.items.some(item => 
                      !item.name.toLowerCase().includes("tea") && 
                      !item.name.toLowerCase().includes("chai")
                    ) && (
                      <Cake className="h-4 w-4 text-accent" />
                    )}
                    <span className="text-sm text-muted-foreground">
                      {order.items.length} item{order.items.length > 1 ? "s" : ""}
                    </span>
                  </div>
                </TableCell>
                <TableCell className="font-semibold">{order.total}</TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border capitalize ${getStatusBadgeClass(order.status)}`}>
                    {order.status}
                  </span>
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">{order.date}</TableCell>
                <TableCell>
                  <Badge variant="outline">{order.paymentMethod}</Badge>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Printer className="h-4 w-4 mr-2" />
                        Print Invoice
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">Cancel Order</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
